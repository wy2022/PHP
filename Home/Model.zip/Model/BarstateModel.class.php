<?php
    namespace Home\Model;
    use Think\Model;
    class BarstateModel extends Model 
    {
		protected $tableName = 'WBOnlineState';	//数据表名
    }
