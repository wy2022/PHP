<?php
    namespace Home\Model;
    use Think\Model;
    class LzmWbChangeModel extends Model 
    {
        protected $tableName = 'LzmWbChange_Tag';
  }
