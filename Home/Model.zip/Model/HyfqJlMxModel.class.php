<?php
  namespace Home\Model;
  use Think\Model;
  class HyfqJlMxModel extends Model 
  {
    protected $tableName = 'WHy_Fq_Jl_Mx';

  
}
