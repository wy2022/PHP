<?php
    namespace Home\Model;
    use Think\Model;
    class LskzhaolingmxModel extends Model 
    {
              
       protected $tableName = 'WTemCardPay_Mx';	//数据表名

      

    }
