<?php
    namespace Home\Model;
    use Think\Model;
    class ZhangmuModel extends Model 
    {
		protected $tableName = 'wt_zhangmu_tongji';	//数据表名
    }
