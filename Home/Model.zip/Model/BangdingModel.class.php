<?php
    namespace Home\Model;
    use Think\Model;
    class BangdingModel extends Model 
    {
        protected $tableName = 'wt_bangding';
  }
