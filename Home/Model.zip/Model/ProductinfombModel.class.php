<?php
    namespace Home\Model;
    use Think\Model;
    class ProductinfombModel extends Model 
    {
        protected $tableName = 'wt_goodsinfo_moban';
  
  }
