<?php
namespace Home\Model;
use Think\Model;
class FangwentjModel extends Model{
	protected $tableName = 'tj_fangwentable';

}