<?php
    namespace Home\Model;
    use Think\Model;
    class NewproductzfModel extends Model 
    {
        protected $tableName = 'cs_goods_paylog';
    
    }
