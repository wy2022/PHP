<?php
    namespace Home\Model;
    use Think\Model;
    class WbSetChangeModel extends Model 
    {
        protected $tableName = 'Wb_Set_Change';
  }
