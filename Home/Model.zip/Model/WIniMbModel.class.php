<?php
    namespace Home\Model;
    use Think\Model;
    class WIniMbModel extends Model 
    {
        protected $tableName = 'Wmb_IniTable';
  }
