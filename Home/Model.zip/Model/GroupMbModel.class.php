<?php
    namespace Home\Model;
    use Think\Model;
    class GroupMbModel extends Model 
    {
        protected $tableName = 'Wmb_grouptable';
  }
