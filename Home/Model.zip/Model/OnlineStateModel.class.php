<?php
    namespace Home\Model;
    use Think\Model;
    class OnlineStateModel extends Model 
    {
      protected $tableName = 'WBOnlineState';
    }
