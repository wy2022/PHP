<?php
    namespace Home\Model;
    use Think\Model;
    class ZhangmufenModel extends Model 
    {
		protected $tableName = 'wt_zhangmu_all';	//数据表名
		
    }
