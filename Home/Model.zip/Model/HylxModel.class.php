<?php
    namespace Home\Model;
    use Think\Model;
    class HylxModel extends Model 
    {
        protected $tableName = 'WHyLxTable';
  }
