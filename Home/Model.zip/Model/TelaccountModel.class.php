<?php
    namespace Home\Model;
    use Think\Model;
    class TelaccountModel extends Model 
    {
        protected $tableName = 'TelAccount';
  }
