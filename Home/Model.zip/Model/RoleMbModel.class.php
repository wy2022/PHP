<?php
    namespace Home\Model;
    use Think\Model;
    class RoleMbModel extends Model 
    {
        protected $tableName = 'Wmb_role';
  }
