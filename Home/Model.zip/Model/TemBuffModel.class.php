<?php
    namespace Home\Model;
    use Think\Model;
    class TemBuffModel extends Model 
    {
        protected $tableName = 'LzmTemBuff';


  }
