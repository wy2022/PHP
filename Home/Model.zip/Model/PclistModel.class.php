<?php
    namespace Home\Model;
    use Think\Model;
    class PclistModel extends Model 
    {
        protected $tableName = 'WComputerList';  
    }
