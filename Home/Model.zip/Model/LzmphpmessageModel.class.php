<?php
    namespace Home\Model;
    use Think\Model;
    class LzmphpmessageModel extends Model 
    {
        protected $tableName = 'LzmPhpMessageTable';
  }
