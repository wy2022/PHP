<?php
    namespace Home\Model;
    use Think\Model;
    class ProductTypeModel extends Model 
    {
        protected $tableName = 'wt_goodstype';  
   }
