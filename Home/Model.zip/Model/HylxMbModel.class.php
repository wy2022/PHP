<?php
    namespace Home\Model;
    use Think\Model;
    class HylxMbModel extends Model 
    {
        protected $tableName = 'Wmb_HylxTable';
  }
